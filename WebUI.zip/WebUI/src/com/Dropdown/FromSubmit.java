package com.Dropdown;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FromSubmit {
	public static void main(String[] args){
		
		System.setProperty("webdriver.chrome.driver", "C:\\Automation_Enterprise\\Selenium\\Resources\\Chrome\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("http://spicejet.com/");
		driver.findElement(By.xpath("//input[@id='ctl00_mainContent_ddl_originStation1_CTXT']")).click();
		driver.findElement(By.xpath("//a[@value='GOI']")).click();
		/*static drop down*/
		
		Select dropdown= new Select(driver.findElement(By.id("ctl00_mainContent_ddl_Adult")));
		dropdown.selectByIndex(7);
	//	dropdown.selectByVisibleText("3 Adults");
	//	dropdown.deselectByValue("8");
		
		/*Check Box*/
		System.out.println(driver.findElement(By.xpath("//input[@id='ctl00_mainContent_chk_IndArm']")).isSelected());
		driver.findElement(By.xpath("//input[@id='ctl00_mainContent_chk_IndArm']")).click();
		System.out.println(driver.findElement(By.xpath("//input[@id='ctl00_mainContent_chk_IndArm']")).isSelected());
		
	}

}
